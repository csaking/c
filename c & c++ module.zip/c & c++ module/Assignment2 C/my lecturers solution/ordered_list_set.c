/* David Flatla    1234567890    AC21008 Assignment #2 */

#include <assert.h>
#include <stdlib.h>
#include "ordered_list_set.h"

/* Allocate an empty ordered list set, initialize its values, and return pointer to it.
   Returns NULL if memory allocation fails. */
OrderedListSet* createOLS() {
	OrderedListSet* ols = malloc(sizeof(OrderedListSet));
	if (ols != NULL) {
		ols->size = 0;
		ols->head = NULL;
		ols->tail = NULL;
	}
	return ols;	// will be NULL or a properly initialized OLS
}

/* Searches 'ols' for value 'v'.
   Returns the OLSNode* containing 'v', if it exists.
   assert(ols != NULL):: [static, so I should always guard against this]
   Returns NULL if 'ols' is empty.
   If 'v' is <= head's data value, return head.
   If 'v' is >= tail's data value, return tail.
   Otherwise returns the OLSNode* immediately after where
   'v' should be inserted if 'v' does not exist. */
static OLSNode* privateSearch(OrderedListSet* ols, int v) {
	assert(ols != NULL);		// ols is invalid
	if (ols->head == NULL || ols->tail == NULL) { return NULL; }	// ols is empty
	else if (ols->head->data >= v) { return ols->head; }			// 'v' <= head
	else if (ols->tail->data <= v) { return ols->tail; }			// 'v' >= tail
	else {
		OLSNode* curr = ols->head;
		while (curr != NULL && curr->data < v) {
			curr = curr->next;
		}
		return curr;
	}
}

/* Add value 'v' to 'ols' at the correct ordered location.
   If 'ols' already contains' v', then do nothing. */
void insertOLS(OrderedListSet* ols, int v) {
	if (ols == NULL) { return; }
	OLSNode* n = privateSearch(ols, v);	// search for node with 'v' or where 'v' should go
	if (n != NULL && v == n->data) {	// 'ols' already contains 'v':: do nothing
		return;
	}
	// initialize the new (blank) node because we now know we are inserting something
	OLSNode* newNode = malloc(sizeof(OLSNode));	// create a new OLSNode
	assert(newNode != NULL);		// guard against malloc fail
	newNode->data = v;				// record 'v' in newNode
	newNode->next = NULL;			// safety - fail fast
	newNode->prev = NULL;			// safety - fail fast
	ols->size = ols->size + 1;		// increment size of ols
	if (n == NULL) { 				// ols is empty:: insert newNode at head and tail
		ols->head = newNode;		// set ols->head to newNode
		ols->tail = newNode;		// set ols->tail to newNode
	}
	else if (v > n->data) {			// append 'v' after 'n' as new tail
		newNode->prev = n;			// newNode's prev is n
		n->next = newNode;			// link in newNode at end of list
		ols->tail = newNode;		// assign tail to newNode
	}
	else /* if (v < n->data) */ { 	// 'v' < n->data:: insert 'v' before 'n' (might be new head)
		newNode->next = n;			// newNode's next is n
		newNode->prev = n->prev;	// newNode's prev is n->prev (may be NULL is n is head)
		if (n->prev != NULL) {		// n is not ols->head
			n->prev->next = newNode;	// link in newNode
			n->prev = newNode;			// link in newNode
		}
		else {						// n is ols->head
			n->prev = newNode;		// link in newNode (at head)
			ols->head = newNode;	// assign head to newNode
		}
	}
}

/* Report true/false whether 'ols' contains value 'v'. */
bool containsOLS(OrderedListSet* ols, int v) {
	if (ols == NULL) { return false; }
	OLSNode* n = privateSearch(ols, v);	// search for node with 'v'
	if (n == NULL) { return false; }	// 'ols' is empty, so does not contain 'v'
	return (n->data == v);				// return if there is a match
}

/* Remove value 'v' from 'ols'. 'ols' may be empty, and 'ols' may not contain 'v'. */
void removeOLS(OrderedListSet* ols, int v) {
	if (ols == NULL) { return; }
	OLSNode* n = privateSearch(ols, v);	// search for node with 'v' or where 'v' should go
	if (n == NULL || (n != NULL && v != n->data)) {	// 'ols' is empty or does not contain 'v':: do nothing
		return;
	}
	else /* (v == n->data) */ {			// 'ols' contains 'v' in node 'n'
		if (ols->size == 1) {			// removing from a single-element OLS
			ols->head = NULL;
			ols->tail = NULL;
		}
		else if (ols->head->data == n->data) {	// removing head
			n->next->prev = NULL;			// unlink 'n' from head of list
			ols->head = n->next;			// set head to n->next
		}
		else if (ols->tail->data == n->data) {	// removing tail
			n->prev->next = NULL;			// unlink 'n' from tail of list
			ols->tail = n->prev;			// set tail to n->prev
		}
		else {			// removing something in between head and tail
			n->next->prev = n->prev;		// unlink n from n->next
			n->prev->next = n->next;		// unlink n from n->prev
		}
		n->next = NULL;					// safety - reset pointers
		n->prev = NULL;					// safety - reset pointers
		free(n); 						// release memory for 'n'
		ols->size = ols->size - 1;		// decrement size of ols
	}
}

/* Free the memory for 'ols's elements and then 'ols' itself. */
void deleteOLS(OrderedListSet* ols) {
	if (ols != NULL) {
		while (ols->size > 0) {
			removeOLS(ols, ols->head->data);
		}
		free(ols);
	}
}
