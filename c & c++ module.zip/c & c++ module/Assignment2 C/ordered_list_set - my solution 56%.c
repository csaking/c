/* Conor King	150024944	AC21008 Assignment 2 */

//includes
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "ordered_list_set.h"

 
OrderedListSet* createOLS()
{
	//create variable "ols" and assign it memory equal to the size of the
	//"OrderedListSet" struct declared in the .h file
	OrderedListSet* ols = malloc(sizeof(OrderedListSet));

	//set its size equal to 0 and return it as the result of the function
	ols->size = 0;
	return ols;
}

//function which creates a Node with data "v" and has no position pointers
//and returns the new Node as the result
//static function not included in the .h file
static OLSNode* getNode(int v)
{
	//create variable "newNode" and assign it memory equal to the size of the
	//"OLSNode" struct declared in the .h file
	OLSNode* newNode = malloc(sizeof(OLSNode));

	//set its data equal to parameter "v" and assign its previous and next
	//pointers to null, then return the "newNode" pointer as the
	//result of the method
	newNode->data = v;	
	newNode->prev = NULL;
	newNode->next = NULL;
	return newNode;
}


bool containsOLS(OrderedListSet* ols, int v)
{
	//create new pointer variable "currentNode" and assign it the value
	//of the head pointer of the OLS
	OLSNode* currentNode = ols->head;

	//for statement will iterate a number of times equal to the size of the OLS
	for(int i=0; i<(ols->size); i++)
		{
		//checks to see if the data of the current node is equal to the
		//parameter "v"
		if(currentNode->data == v)
		{
			//if true, returns true as the result and forcefully
			//exits the for loop
			return true;
			break;
		}
		else
		{	
			//if false, assigns the currentNode variable to equal the
			//Node that currentNode's next pointer points to
			//for loop will then iterate again
			currentNode = currentNode->next;
		}
	}
	//if for loop executes and no true result is returned, parameter "v"
	//must then not exist within the OLS, so function will return a false result
	return false;
}


void insertOLS(OrderedListSet* ols, int v)
{
	//get an empty node
	OLSNode* newNode = getNode(v);
	if(ols->size == 0)
	{
		//if OLS is currently empty, set the head and tail of
		//the OLS to equal this new node, then iterate the OLS
		//size variable by 1
		ols->head = newNode;
		ols->tail = newNode;
		ols->size++;
	}
	else
	{
		//if OLS is not empty then check to see if a node exists already
		//in the OLS with data equal to the v parameter
		if(containsOLS(ols, v) == true)
		{
			//if it does exist, then display an error message
			printf("An error has occurred.  There already exists a node with the defined value.");
		}
		else
		{
			//if it does not exist, then check to see if the data of
			//the head node in the OLS is greater than paramter v
			if(ols->head->data > v)
			{
				//if it is, then the newNode becomes the head node of
				//the OLS, and the previous head becomes second
				//in the list
				newNode->next = ols->head;
				ols->head->prev = newNode;
				ols->head = newNode;
				ols->size++;
			}
			else if(ols->tail->data < v)
			{
				//else, if the tail node's data is less than parameter v
				//then the newNode is assigned to as the tail node
				//previous tail node becomes second to last node
				newNode->prev = ols->tail;
				ols->tail->next = newNode;
				ols->tail = newNode;
				ols->size++;
			}
			else
			{
				//else the newNode is not the new head or tail node
				OLSNode* currentNode = ols->head->next;
				//create a boolean checker variable
				bool checker = false;
				while(checker == false)
				{
					//while the checker is not true
					//check to see if the currentNode's data is less than 
					//the parameter v
					if(currentNode->data < v)
					{
						//if it is less, then assign current node
						//to be the next node in the linked list
						currentNode = currentNode->next;
					}
					//otherwise, check to see if the currentNode is 
					//greater than the parameter v			
					else if(currentNode->data > v)
					{
						//if it is greater, then insert the currentNode into the list
						//assigning its next and previous pointers
						//to the appropriate nodes, then set the checker equal to true 
						newNode->prev = currentNode->prev;
						currentNode->prev->next = newNode;
						currentNode->prev = newNode;
						newNode->next = currentNode;
						ols->size++;
						checker = true;
					}
					//else if all these checks fail
					else
					{
						//display error message to user
						printf("An error has occurred somewhere.\n");
						printf("Data has not been added to the list\n");
						//then break out of while loop and end the function
						break;
					}
					
				}
			}
		}
	}		
}


void removeOLS(OrderedListSet* ols, int v)
{
	//if OLS is empty, data cannot be removed so an error will occur
	if(ols->size == 0)
	{
		//print error message
		printf("An error has occurred. The OLS is currently empty.\n");
		printf("Data could not be removed from the OLS.\n");
	}
	//otherwise, if OLS is not empty but v does not exist within it
	//then data cannot be removed so an error will occur
	else if(containsOLS(ols, v) == false)
	{
		//print error message
		printf("An error has occurred. Data does not exist within the OLS\n");
		printf("Data could not be removed from the OLS.\n");
	}
	//otherwise check to see if there is only one node (both the head and tail) in the OLS
	else if(ols->size == 1)
	{
		//make a temporary node and assign it to be equal to the head/tail node
		OLSNode* tempNode = ols->head;
		//make the head and tail equal to null then free tempNode's memory and decrement the size of the OLS
		ols->head = NULL;
		ols->tail = NULL;
		free(tempNode);
		ols->size--;
	}
	//otherwise check to see if v is the data of the head node
	else if(ols->head->data == v)
	{
		//make the head node of the OLS equal to the next node in the OLS
		ols->head = ols->head->next;
		//make the head node's next node's previous node (effectively making it point back to itself) equal to null
		ols->head->next->prev = NULL;
		free(ols->head);
		//decrement the size of the OLS
		ols->size--;
	}
	//otherwise check to see if v is the data of the tail node
	else if(ols->tail->data == v)
	{	
		//create a node to store the tail node 
		OLSNode* delNode = ols->tail;
		//use delNode to point back to the tail and make it null
		delNode->prev->next = NULL;
		//make the second last node the new tail of the OLS and free the memory of delNode
		ols->tail = delNode->prev;
		free(delNode);
		//decrement size by 1
		ols->size--;
	}	
	//otherwise v should be data of a node within the list
	else
	{
	//create a temporary node to hold the head node of the OLS
	OLSNode* currentNode = ols->head;
	//iterate through a number of times equal to the size of the OLS
	for(int i=0; i<(ols->size); i++)
		{
			//check to see if the current node equals the v parameter
			if(currentNode->data == v)
			{
				//if it does, then change pointers to remove it from the list, decrement the size of the OLS and free the memory of the currentNode
				currentNode->next->prev = currentNode->prev;
				currentNode->prev->next = currentNode->next;
				ols->size--;
				free(currentNode);
				break;
			}
			else
			{	
				//if it does not, make the currentNode equal the next node on the list and iterate the loop again
				currentNode = currentNode->next;
			}
		}
	}
}


void deleteOLS(OrderedListSet* ols)
{
	//free the memory of the OLS
	memset(ols, 0, sizeof(OLSNode));
	free(ols);
}
