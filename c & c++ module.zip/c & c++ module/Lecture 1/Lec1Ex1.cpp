/**
Mark Snaith
AC21008
Lecture 1 - First C++ program
**/

#include <iostream> //include the iostream library - provides input and output, amongst other things

using namespace std; //tell the compiler we're using classes and objects from the 'std' namespace

 //main method - entry point to the program
int main(){
 	//basic syntax for printing to the screen
	cout << "Hello world!" << endl;
}