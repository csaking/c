#include <iostream>

using namespace std;

int main(){
	int num1, num2;
	cout << "Please enter a number: ";
	cin >> num1; //wait for user input; store into num1
	
	cout << "Please enter another number: ";
	cin >> num2; //wait for user input; store into num2
	
	int result = num1 * num2;
	
	cout << "The result is: " << result << endl;
	return 0;
}