#include "MyClass.h"

using namespace std;

int MyClass::getMyNum(){
	return myNum;
}

MyClass::MyClass(bool val){
	trueFalse = val;
}

void MyClass::setMyNum(int val){
	myNum = val;
}

int main(){
	MyClass* instance = new MyClass(true);
	instance->setMyNum(2);
	cout << instance->getMyNum() <<endl;
}