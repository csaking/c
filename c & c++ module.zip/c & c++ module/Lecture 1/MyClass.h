#include <iostream>

using namespace std;

class MyClass{
	private:
		int myNum;
		bool trueFalse;
	public:
		MyClass(bool theVal);
		int getMyNum();
		void setMyNum(int val);
};
	