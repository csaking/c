#include <iostream>

using namespace std;

const int multiplier = 5; //define a const value - can't change in the program

// method to multiply numbers
int multiplyNumbers(int num1, int num2){
	return num1 * num2;
}

int main(){
	int num1, num2;
	cout << "Please enter a number: ";
	cin >> num1;
	
	cout << "Please enter another number: ";
	cin >> num2;
	
	int result = multiplyNumbers(num1, num2); //call the multiplyNumbers method
	cout << "The result is: " << result << endl;

	result = result * multiplier; //use the const to change the result
	cout << "Multiplied by " << multiplier << " the result is: " << result << endl;
	
	return 0;
}