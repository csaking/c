/*
Conor King
150024944
AC21008
*/

#ifndef H_FRAME_HEADER
#define H_FRAME_HEADER

//variables
typedef struct Frame Frame;
struct Frame {
	int data;
	Frame *next;
};

#endif
