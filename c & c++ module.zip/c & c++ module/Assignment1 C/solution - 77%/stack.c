/*
Conor King
150024944
AC21008
*/

//includes
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "stack.h"
#include "frame_manager.c"

//prototype function definitons
Stack* createStack()
{
	Stack *stk = malloc(sizeof(stk));
	stk->size = 0;
	return stk;
}

bool isEmpty(Stack* stk)
{
	if (stk->size == 0)
	{
		printf("Stack is empty.\n");
		return true;
	}
	else
	{
		printf("Stack is not empty.\n");
		return false;
	}
}

void push(Stack* stk, int x)
{
	Frame *newHead = getFrame();
	newHead->data = x;
	newHead->next = stk->head;
	stk->head = newHead;
	stk->size++;
}

int pop(Stack* stk)
{
	if (isEmpty(stk));
	{
		printf("An underflow error has occurred.\n");
		return 1;
	}
	int r = stk->head->data;
	stk->head = stk->head->next;
	releaseFrame(stk->head);
	stk->size--;
	return r;
}

void releaseStack(Stack* stk)
{
	memset(stk, 0, sizeof(Stack));
	free(stk);
}

