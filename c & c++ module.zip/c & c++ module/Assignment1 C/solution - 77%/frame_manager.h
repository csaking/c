/*
Conor King
150024944
AC21008
*/

//header info
#ifndef H_FRAME_MANAGER
#define H_FRAME_MANAGER

//includes
#include "frame.h"

//prototype function declaration
Frame* getFrame();
void releaseFrame(Frame* oldFrame);

#endif
