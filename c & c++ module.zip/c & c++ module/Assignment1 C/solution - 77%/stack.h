/*
Conor King
150024944
AC21008
*/

//header info
#ifndef H_STACK_HEADER
#define H_STACK_HEADER

//includes
#include "frame.h"
#include <stdbool.h>

//struct definition
typedef struct Stack Stack;
struct Stack {
	int size;
	Frame *head;
};

//prototype function declaration
Stack* createStack();
bool isEmpty(Stack* stk);
void push(Stack* stk, int x);
int pop(Stack* stk);
void releaseStack(Stack* stk);

#endif
