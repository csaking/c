/*
Conor King
150024944
AC21008
*/

//includes
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "frame.h"

//prototype function definitions
Frame* getFrame()
{
	Frame* newFrame = malloc(sizeof(Frame));
	return newFrame;
}

void releaseFrame(Frame* oldFrame)
{
	memset(oldFrame, 0, sizeof(Frame));
	free(oldFrame);
}

