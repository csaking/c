/*
Conor King
150024944
AC21008
*/

//includes
#include "stack.h"
#include <stdio.h>
#include <stdbool.h>

//function definitions
int typicalTest()
{
	//typical cases
	Stack *newStk = createStack();
	isEmpty(newStk);
	push(newStk, 4);
	pop(newStk);
	releaseStack(newStk);
	return 0;
}

int errorTest()
{
	//popping from an empty stack
	Stack *emptyStk = createStack();
	isEmpty(emptyStk);
	pop(emptyStk);
	return 0;
}

//main function definition
int main()
{
	int tester;

	//typical cases test
	tester = typicalTest();
	if (tester !=0)
	{
		printf("Typical tests of stack functions have failed.\n");
	}

	//popping from an empty stack test
	tester = errorTest();
	if (tester !=0)
	{
		printf("Data has been popped from an empty stack, error test has failed.\n");
	}
}


