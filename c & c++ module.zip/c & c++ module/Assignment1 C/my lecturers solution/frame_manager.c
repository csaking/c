/* David Flatla -- AC21008 -- A1 */

#include "frame_manager.h"
#include <stdlib.h>

/* Get a pointer to a newly allocated Frame. Initialize frame
   to defaults. Returns NULL if no Frames available. */
Frame* getFrame()
{
	// allocate and initialize on success
	Frame* f = malloc(sizeof(Frame));
	if (f != NULL) {
		f->data = 0;
		f->next = NULL;
	}
	return f;	// returns NULL if malloc failed

	// can also allocate using 'calloc'
	// calloc returns NULL if memory allocation fails
	// calloc sets all values of Frame to 0
	// return calloc(1, sizeof(Frame));
}

/* Reset 'oldFrame' and deallocate its memory. */
void releaseFrame(Frame* oldFrame)
{
	if (oldFrame == NULL) { return; }
	oldFrame->data = 0;
	oldFrame->next = NULL;
	free(oldFrame);
}
