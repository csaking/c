/* David Flatla -- AC21008 -- A1 */

#include <assert.h>
#include <stdlib.h>
#include "stack.h"

/* Create a new Stack with size 0. */
Stack* createStack()
{
	Stack* stk = malloc(sizeof(Stack));
	if (stk != NULL) {
		stk->size = 0;
		stk->head = NULL;
	}
	return stk;	// returns NULL if malloc failed
}

/* Return true if 'stk' is NULL or empty. False otherwise. */
bool isEmpty(Stack* stk)
{
	return (stk == NULL || stk->size <= 0);
}

/* Add 'x' to the top of Stack 'stk'. Does nothing if
   'stk' is NULL or if allocation of new Frame fails. */
void push(Stack* stk, int x)
{
	if (stk != NULL) {
		Frame *newHead = getFrame();
		if (newHead != NULL) {
			newHead->data = x;
			newHead->next = stk->head;
			stk->head = newHead;
			stk->size = (stk->size + 1);
		}
	}
}

/* Remove and return the top value of Stack 'stk'.
   Requires that 'stk' is not empty, and barfs if it is. */
int pop(Stack* stk)
{
	assert(!isEmpty(stk));	// barf if 'stk' is not empty
	int r = stk->head->data;
	Frame *oldHead = stk->head;
	stk->head = stk->head->next;
	stk->size = (stk->size - 1);
	releaseFrame(oldHead);
	return r;
}

/* Delete all contents of stk (using 'pop'), then delete stk itself. */
void releaseStack(Stack* stk)
{
	while (!isEmpty(stk)) {	// won't enter loop if 'stk' is NULL
		pop(stk);
	}
	free(stk);	// 'free' is robust to 'stk' being NULL
}
