/* David Flatla -- AC21008 -- A1 */

#include <stdio.h>
#include "stack.h"

/* Print a message about whether 'stk' is empty or not. */
void printIsEmptyLong(Stack* stk)
{
	if (stk == NULL) { return; }
	if (isEmpty(stk)) { printf("stack is empty\n"); }
	else { printf("stack is not empty.\n"); }
}

void printIsEmptyShort(Stack* stk)
{
	if (stk == NULL) { return; }
	if (isEmpty(stk)) { printf(".e "); }
	else { printf(".!e "); }
}

int main()
{
	// create a stack and make sure it is empty
	Stack* stk = createStack();
	printIsEmptyLong(stk);

	// push a number onto the stack and make sure it is not empty
	printf("Push 1\n");
	push(stk, 1);
	printIsEmptyLong(stk);

	// pop the number off the stack. check it and make sure stack is empty again
	printf("Pop...");
	printf("%d\n", pop(stk));
	printIsEmptyLong(stk);

	// populate the (empty) stack with 20 numbers
	// print out emptiness of stack after each push
	int loops = 20;
	for (int i=1; i<=loops; i=i+1) {
		push(stk, i);
		printf("%d", i);
		printIsEmptyShort(stk);
	}
	printf("\n");

	// then push off all of those 20 numbers and report emptiness
	while (!isEmpty(stk)) {
		printf("%d", pop(stk));
		printIsEmptyShort(stk);
	}
	printf("\n");
	printIsEmptyLong(stk);

	// should blow up by violating the assert in pop
//	pop(stk);

	// delete the stack
	releaseStack(stk);

	return 0;
}
