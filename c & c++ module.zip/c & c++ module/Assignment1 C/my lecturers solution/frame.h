/* David Flatla -- AC21008 -- A1 */

#ifndef HEADER_FRAME_H
#define HEADER_FRAME_H

/* The Frame struct to be used everywhere. */
typedef struct MyFrame{
	int data;
	struct MyFrame *next;
} Frame;

#endif
