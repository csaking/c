/* David Flatla -- AC21008 -- A1 */

#ifndef HEADER_FRAME_MANAGER_H
#define HEADER_FRAME_MANAGER_H

#include "frame.h"

/* Function prototype: get a pointer to a newly allocated Frame.
   Initialize frame to defaults. Returns NULL if no Frames available. */
Frame* getFrame();

/* Function prototype: deallocate 'oldFrame's memory.
   Resets 'oldFrame' contents before deallocation. */
void releaseFrame(Frame* oldFrame);

#endif
