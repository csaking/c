/* David Flatla -- AC21008 -- A1 */

#ifndef HEADER_STACK_H
#define HEADER_STACK_H

#include <stdbool.h>
#include "frame_manager.h"

/* The Stack struct to be used everywhere. */
typedef struct MyStack{
	int size;
	struct MyFrame *head;
} Stack;

/* Create a new Stack with size 0. */
Stack* createStack();

/* Return true if the stack is empty. False otherwise. */
bool isEmpty(Stack* stk);

/* Add 'x' to the top of Stack 'stk'. */
void push(Stack* stk, int x);

/* Remove and return the top value of Stack 'stk'.
   Requires that 'stk' is not empty, and barfs if it is. */
int pop(Stack* stk);

/* Delete all contents of stk (using 'pop'), then delete stk itself. */
void releaseStack(Stack* stk);

#endif
