#include <iostream>
#include <vector>

using namespace std;

void vector1(){
	/* Test data
	    So in the map, 10=>4; 6=>9; 12=>3 */
	int hashes[] = {10, 6, 12};
	int values[] = {4, 9, 3};

	// declares a new vector of undetermined size
	vector<int>* v = new vector<int>();
	
	for(int i=0;i<3;i++){
		int hash = hashes[i];
		
		cout << "Index required: " << hash << ";" << " Current vector size: " << v->size() << endl;
		
		if(v->size() < hash){
			cout << "> Resizing vector to " << (hash + 1) << endl;
			v->resize(hash+1, -1); // +1 because we start at 0 remember! Also set all unfilled elements = -1
		}else{
			cout << "> Vector big enough" << endl;
		}
		
		v->at(hash) = values[i];
		
	}
	
	cout << endl << "Output: " << endl <<endl;
	
	for(int i=0;i<v->size();i++){
		cout << "Value at position " << i << ": " << v->at(i) << endl;
	}
}

void vector2(){
	/* Test data
	    So in the map, 10=>4; 6=>9; 12=>3 */
	int hashes[] = {10, 6, 12};
	int values[] = {4, 9, 3};

	// declares a new vector of size 10, with all elements having a default value of -1
	vector<int>* v = new vector<int>(10,-1);
	
	for(int i=0;i<3;i++){
		int hash = hashes[i];
		
		if(v->size() <= hash){
			hash = hash % v->size();
		}
		v->at(hash) = values[i];
	}
	cout << "Output: " << endl <<endl;
	
	for(int i=0;i<v->size();i++){
		cout << "Value at position " << i << ": " << v->at(i) << endl;
	}
}

int main(){
	cout << "===Vector method 1===" << endl << endl;
	vector1();

	cout << endl << "===Vector method 2===" << endl << endl;
	vector2();
}