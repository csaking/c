#include <iostream>

#ifndef _HASHTABLE_H
#define _HASHTABLE_H

#include "ListNode.h" //also includes Person.h

using namespace std;

class HashTable{
	private:
		int hash(string input); //hashing method has private access only
		//choose an array or vector here to actually store your data
		
	public:
		void addToTable(string key, Person value);
		Person getFromTable(string key);
};
#endif
