#include <iostream>

#ifndef _LISTNODE_H
#define _LISTNODE_H

#include "Person.h" //to be implemented

using namespace std;

class ListNode{
	private:
		Person* data;
		ListNode* next;
	
	public:
		ListNode* getNext();
		void setNext(ListNode* n);
		Person* getData();
		void setData(Person* p);
};
#endif
